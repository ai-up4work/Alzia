"use client"

import type React from "react"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { ArrowRight, Search } from "lucide-react"
import { AnimatedText } from "@/components/animated-text"
import Link from "next/link"
import { useRouter } from "next/navigation"

export function HeroSection() {
  const imageContainerRef = useRef<HTMLDivElement>(null)
  const [currentSlide, setCurrentSlide] = useState(0)
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  const slides = [
    {
      image: "/hero-1.jpg",
      subtitle: "Parisian Luxury Beauty",
      title: ["Discover your", "radiant beauty"],
      description:
        "Exquisite cosmetics crafted in Paris with the finest ingredients. Experience luxury that transforms your everyday routine into a moment of pure elegance.",
    },
    {
      image: "/hero-2.jpg",
      subtitle: "Timeless Elegance",
      title: ["Elevate your", "skincare ritual"],
      description:
        "Transform your skin with our luxurious skincare collection. Each product is formulated to nourish, rejuvenate, and reveal your natural radiance.",
    },
    {
      image: "/hero-3.jpg",
      subtitle: "Natural Brilliance",
      title: ["Express your", "unique beauty"],
      description:
        "From vibrant makeup to nourishing skincare, discover products that celebrate your individuality and enhance your natural beauty.",
    },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [slides.length])

  const slide = slides[currentSlide]

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/shop?search=${encodeURIComponent(searchQuery)}`)
    }
  }

  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      <div
        ref={imageContainerRef}
        className="absolute inset-0 w-full h-full overflow-hidden transition-all duration-1000 ease-out"
      >
        <img
          key={currentSlide}
          src={slide.image || "/placeholder.svg?height=1080&width=1920&query=luxury cosmetics hero"}
          alt={slide.subtitle}
          className="w-full h-full object-cover animate-zoom-in"
        />
        {/* Subtle dark overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/70 via-foreground/40 to-transparent" />
      </div>

      {/* Content overlay */}
      <div className="relative max-w-7xl mx-auto px-4 md:px-6 lg:px-8 w-full h-full flex flex-col items-start justify-center">
        <div className="max-w-2xl">
          <p className="text-xs md:text-sm uppercase tracking-[0.2em] md:tracking-[0.25em] text-background/80 font-medium mb-3 md:mb-6 animate-fade-up">
            {slide.subtitle}
          </p>

          {/* Desktop/Tablet Heading */}
          <h1 className="hidden md:block font-serif text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-medium leading-[1.1] text-background text-balance mb-8">
            <AnimatedText text={slide.title[0]} delay={0.2} />
            <br />
            <span className="text-accent">
              <AnimatedText text={slide.title[1]} delay={0.6} />
            </span>
          </h1>

          {/* Mobile Heading - More Compact */}
          <h1 className="block md:hidden font-serif text-[2rem] leading-[1.15] font-medium text-background text-balance mb-4">
            <AnimatedText text={slide.title[0]} delay={0.2} />
            <br />
            <span className="text-accent">
              <AnimatedText text={slide.title[1]} delay={0.4} />
            </span>
          </h1>

          {/* Desktop/Tablet Description */}
          <p className="hidden md:block text-lg text-background/90 leading-relaxed mb-10 max-w-lg animate-fade-up animation-delay-400">
            {slide.description}
          </p>

          {/* Mobile Description - Shorter */}
          <p className="block md:hidden text-sm text-background/90 leading-relaxed mb-6 max-w-sm animate-fade-up animation-delay-400">
            {slide.description}
          </p>

          <div className="mb-8 md:mb-10">
            <form
              onSubmit={handleSearch}
              className="flex items-center gap-2 md:gap-3 bg-background/20 backdrop-blur-md rounded-full px-4 md:px-6 py-3 md:py-4 border border-background/30 hover:border-background/50 transition-colors max-w-md"
            >
              <Search className="w-5 h-5 text-background/70 flex-shrink-0" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent text-sm md:text-base text-background placeholder-background/60 outline-none font-light"
              />
              <button
                type="submit"
                className="text-background/70 hover:text-background transition-colors flex-shrink-0 font-medium text-sm"
              >
                Search
              </button>
            </form>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 md:gap-4 pt-4 md:pt-8">
            <Button
              asChild
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-full px-6 md:px-8 py-5 md:py-6 text-sm md:text-base group font-cinzel"
            >
              <Link href="/account/">
                Get Started
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="rounded-full px-6 md:px-8 py-5 md:py-6 text-sm md:text-base border-background/30 hover:bg-background/10 text-background bg-transparent backdrop-blur-sm"
            >
              <Link href="/shop">Shop</Link>
            </Button>
          </div>

          <div className="flex gap-2 pt-12 md:pt-16">
            {slides.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentSlide(index)}
                className={`transition-all duration-300 rounded-full ${
                  index === currentSlide
                    ? "w-8 md:w-10 h-2 md:h-2.5 bg-background/90"
                    : "w-2 md:w-2.5 h-2 md:h-2.5 bg-background/40 hover:bg-background/60"
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
